package com.hostelpg.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.hostelpg.management")  // ✅ Ensure correct package scanning
public class HostelPgManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(HostelPgManagementApplication.class, args);
    }
}
