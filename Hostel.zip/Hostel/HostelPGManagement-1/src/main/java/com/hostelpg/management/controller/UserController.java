package com.hostelpg.management.controller;

import com.hostelpg.management.model.User;
import com.hostelpg.management.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")  // Base path for user-related requests
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")  // This method handles POST requests to /users/register
    public User registerUser(@RequestBody User user) {
        return userService.registerUser(user);
    }
}

