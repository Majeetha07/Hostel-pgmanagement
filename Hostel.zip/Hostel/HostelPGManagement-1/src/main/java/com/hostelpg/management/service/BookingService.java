package com.hostelpg.management.service;

import com.hostelpg.management.model.Booking;
import java.util.List;

public interface BookingService {
    Booking saveBooking(Booking booking); // ✅ Save Booking
    List<Booking> getAllBookings();       // ✅ Get All Bookings
    Booking getBookingById(Long id);      // ✅ Get Booking by ID
    void deleteBooking(Long id);          // ✅ Delete Booking
}
