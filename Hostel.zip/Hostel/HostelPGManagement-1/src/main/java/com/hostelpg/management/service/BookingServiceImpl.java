package com.hostelpg.management.service;

import com.hostelpg.management.model.Booking;
import com.hostelpg.management.repository.BookingRepository;

import org.springframework.stereotype.Service;
import java.util.List;


@Service  // ✅ REQUIRED to register this as a Spring Bean
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;

    // ✅ Constructor Injection (No need for @Autowired in Spring Boot 4.3+)
    public BookingServiceImpl(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @Override
    public Booking saveBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Booking getBookingById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking Not Found with ID: " + id));
    }

    @Override
    public void deleteBooking(Long id) {
        if (!bookingRepository.existsById(id)) {
            throw new RuntimeException("Cannot delete, Booking Not Found with ID: " + id);
        }
        bookingRepository.deleteById(id);
    }
}
