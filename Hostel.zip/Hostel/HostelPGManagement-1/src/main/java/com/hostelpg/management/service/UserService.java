package com.hostelpg.management.service;

import com.hostelpg.management.model.User;

public interface UserService {
    User registerUser(User user);
}
