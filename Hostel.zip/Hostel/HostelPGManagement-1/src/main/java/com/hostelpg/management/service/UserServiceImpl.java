package com.hostelpg.management.service;

import com.hostelpg.management.model.User;
import com.hostelpg.management.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User registerUser(User user) {
        try {
            return userRepository.save(user);  // Save user to database
        } catch (DataIntegrityViolationException e) {
            // Handle specific database constraints violation (e.g., duplicate username or email)
            throw new RuntimeException("User data integrity violation: " + e.getMessage());
        } catch (Exception e) {
            // General exception handling
            throw new RuntimeException("Error registering user: " + e.getMessage());
        }
    }
}
