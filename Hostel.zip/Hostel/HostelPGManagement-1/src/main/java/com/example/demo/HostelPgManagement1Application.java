package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostelPgManagement1Application {

	public static void main(String[] args) {
		SpringApplication.run(HostelPgManagement1Application.class, args);
	}

}
